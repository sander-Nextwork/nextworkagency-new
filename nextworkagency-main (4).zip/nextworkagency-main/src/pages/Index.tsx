import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import LogoSlider from "@/components/LogoSlider";
import ResultsSection from "@/components/ResultsSection";
import ProcessSection from "@/components/ProcessSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import CalendlySection from "@/components/CalendlySection";
import TeamSection from "@/components/TeamSection";
import FinalCTASection from "@/components/FinalCTASection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <LogoSlider />
        <ResultsSection />
        <ProcessSection />
        <TestimonialsSection />
        <CalendlySection />
        <TeamSection />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
