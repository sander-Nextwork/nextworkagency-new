import { useEffect, useRef, useState } from "react";

type ScrollRevealOptions = {
  root?: IntersectionObserverInit["root"];
  rootMargin?: IntersectionObserverInit["rootMargin"];
  threshold?: IntersectionObserverInit["threshold"];
};

export function useScrollReveal(options: ScrollRevealOptions = {}) {
  const elementRef = useRef<HTMLElement | null>(null);
  const [revealed, setRevealed] = useState(false);
  const { root = null, rootMargin = "0px 0px -8% 0px", threshold = 0.2 } = options;

  useEffect(() => {
    if (revealed) {
      return;
    }

    if (typeof window === "undefined") {
      return;
    }

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) {
      setRevealed(true);
      return;
    }

    const node = elementRef.current;
    if (!node) {
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setRevealed(true);
            observer.unobserve(entry.target);
          }
        });
      },
      {
        root,
        rootMargin,
        threshold,
      },
    );

    observer.observe(node);

    return () => {
      observer.disconnect();
    };
  }, [revealed, root, rootMargin, threshold]);

  return {
    ref: elementRef,
    revealed,
  };
}
