import { useCallback, useEffect, useState } from "react";
import type { CarouselApi } from "@/components/ui/carousel";

type AutoplayOptions = {
  delay?: number;
};

export function useCarouselAutoplay(api: CarouselApi | null, options: AutoplayOptions = {}) {
  const { delay = 3000 } = options;
  const [isPaused, setIsPaused] = useState(false);
  const [isDocumentHidden, setIsDocumentHidden] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const handleChange = () => setPrefersReducedMotion(media.matches);
    handleChange();
    media.addEventListener("change", handleChange);
    return () => media.removeEventListener("change", handleChange);
  }, []);

  useEffect(() => {
    const handleVisibility = () => setIsDocumentHidden(document.hidden);
    handleVisibility();
    document.addEventListener("visibilitychange", handleVisibility);
    return () => document.removeEventListener("visibilitychange", handleVisibility);
  }, []);

  useEffect(() => {
    if (!api || isPaused || isDocumentHidden || prefersReducedMotion) {
      return;
    }

    const intervalId = window.setInterval(() => {
      api.scrollNext();
    }, delay);

    return () => window.clearInterval(intervalId);
  }, [api, isPaused, isDocumentHidden, prefersReducedMotion, delay]);

  const pause = useCallback(() => setIsPaused(true), []);
  const resume = useCallback(() => setIsPaused(false), []);

  return { pause, resume, isPaused };
}
