import { Button } from "@/components/ui/button";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { scrollToId } from "@/lib/utils";

const FinalCTASection = () => {
  const { ref, revealed } = useScrollReveal({ threshold: 0.1, rootMargin: "0px 0px -12% 0px" });
  const scrollToCalendly = () => {
    scrollToId("calendly");
  };

  return (
    <section
      ref={ref}
      className={`section-padding scroll-reveal ${revealed ? "scroll-reveal-visible" : ""}`}
    >
      <div className="container-narrow text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          Klaar voor meer plaatsingen?
        </h2>
        <p className="text-lg text-muted-foreground mb-10 max-w-2xl mx-auto">
          Bekijk hoe jouw bureau meer kandidaten krijgt via een voorspelbare stroom gekwalificeerde kandidaten.
        </p>
        <Button variant="hero" size="xl" onClick={scrollToCalendly}>
          Plan een demo met Sander
        </Button>
      </div>
    </section>
  );
};

export default FinalCTASection;
