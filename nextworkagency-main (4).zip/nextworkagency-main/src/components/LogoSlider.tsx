import logoVertx from "@/assets/logos/logo-vertx.png";
import logoKamgroep from "@/assets/logos/logo-kamgroep.png";
import logoCareselect from "@/assets/logos/logo-careselect.png";
import logoUncapped from "@/assets/logos/logo-uncapped.png";
import logoRab from "@/assets/logos/logo-rab.png";
import logoDolmans from "@/assets/logos/logo-dolmans.png";
import logoGoedgemerkt from "@/assets/logos/logo-goedgemerkt.jpg";
import logoKlikinzorg from "@/assets/logos/logo-klikinzorg.jpg";
import logoTechresources from "@/assets/logos/logo-techresources.jpg";
import logoSolvers from "@/assets/logos/logo-solvers.png";
import logoIzybottles from "@/assets/logos/logo-izybottles.png";
import logoRecruitersnetwork from "@/assets/logos/logo-recruitersnetwork.png";
import logoGamma from "@/assets/logos/logo-gamma.png";
import logoKarwei from "@/assets/logos/logo-karwei.png";
import biaflexLogo from "@/assets/logos/Biaflex logo.png";
import curacentraalLogo from "@/assets/logos/Curacentraal logo.jpeg";
import deUitzendersLogo from "@/assets/logos/DeUitzenders-Logo-ComingSoon.png";
import keepersLogo from "@/assets/logos/Keepers logo.png";
import matchdLogo from "@/assets/logos/MatchD logo.png";
import sigtLogo from "@/assets/logos/Sigt recruitment logo.jpeg";
import solidSourcingLogo from "@/assets/logos/Solid Sourcing logo.jpeg";
import mooringItLogo from "@/assets/logos/mooring_it_logo.jpeg";
import wtRecruitmentLogo from "@/assets/logos/wt_recruitment_logo.jpeg";

import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { useState, useEffect, type CSSProperties } from "react";

const logos = [
  { src: logoVertx, alt: "Vertx" },
  { src: logoRecruitersnetwork, alt: "Recruiters Network" },
  { src: logoSolvers, alt: "Solvers" },
  { src: logoIzybottles, alt: "IZY Bottles" },
  { src: logoDolmans, alt: "Dolmans" },
  { src: logoRab, alt: "RAB Bouwcenter" },
  { src: logoGamma, alt: "Gamma" },
  { src: logoKarwei, alt: "Karwei" },
  { src: logoTechresources, alt: "Tech Resources" },
  { src: logoUncapped, alt: "Uncapped Recruitment" },
  { src: logoCareselect, alt: "Care Select" },
  { src: logoKlikinzorg, alt: "Klik in Zorg" },
  { src: logoKamgroep, alt: "KAM Groep" },
  { src: logoGoedgemerkt, alt: "Goedgemerkt" },
  { src: biaflexLogo, alt: "Biaflex" },
  { src: curacentraalLogo, alt: "Curacentraal" },
  { src: deUitzendersLogo, alt: "De Uitzenders" },
  { src: keepersLogo, alt: "Keepers" },
  { src: matchdLogo, alt: "MatchD" },
  { src: sigtLogo, alt: "Sigt Recruitment" },
  { src: solidSourcingLogo, alt: "Solid Sourcing" },
  { src: mooringItLogo, alt: "Mooring IT" },
  { src: wtRecruitmentLogo, alt: "WT Recruitment" },
];

const MARQUEE_DURATION_SECONDS = 56;

const LogoSlider = () => {
  const { ref, revealed } = useScrollReveal({ threshold: 0, rootMargin: "0px 0px -12% 0px" });
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  // Check for reduced motion preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);

    const handleChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  return (
    <section
      ref={ref}
      className={`py-14 section-white border-y border-border overflow-hidden scroll-reveal ${revealed ? "scroll-reveal-visible" : ""}`}
      aria-label="Klantenlogo's"
    >
      <div className="container-wide mb-8">
        <p className="text-center text-sm font-medium text-muted-foreground uppercase tracking-wider">
          Vertrouwd door toonaangevende organisaties
        </p>
      </div>

      <div className="relative">
        {/* Gradient overlays */}
        <div className="absolute left-0 top-0 bottom-0 w-28 sm:w-32 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-28 sm:w-32 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />

        <div
          className="overflow-hidden w-full"
          aria-label="Klantenlogo marquee"
        >
          <div
            className={`flex w-max items-center ${prefersReducedMotion ? "" : "animate-logo-marquee"}`}
            style={{ "--logo-marquee-duration": `${MARQUEE_DURATION_SECONDS}s` } as CSSProperties}
          >
            {[0, 1].map((copyIndex) => (
              <div
                key={`logo-copy-${copyIndex}`}
                className="flex items-center gap-8 sm:gap-12 md:gap-16 pr-8 sm:pr-12 md:pr-16"
                aria-hidden={copyIndex === 1}
              >
                {logos.map((logo, index) => (
                  <div
                    key={`${copyIndex}-${index}`}
                    className="h-10 w-[150px] flex-shrink-0 flex items-center justify-center"
                  >
                    <img
                      src={logo.src}
                      alt={logo.alt}
                      loading="lazy"
                      decoding="async"
                      width={128}
                      height={40}
                      draggable="false"
                      className="max-h-10 max-w-full w-auto object-contain opacity-80 hover:opacity-100 transition-opacity"
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LogoSlider;
