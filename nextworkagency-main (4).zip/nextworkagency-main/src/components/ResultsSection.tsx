import { TrendingUp, Users, Settings } from "lucide-react";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";

const results = [
  {
    icon: TrendingUp,
    title: "Voorspelbare instroom",
    description: "Een constante stroom gekwalificeerde kandidaten die direct binnen jouw profiel passen.",
  },
  {
    icon: Users,
    title: "Meer plaatsingen",
    description: "Doordat jouw team zich volledig kan focussen op gesprekken en matching.",
  },
  {
    icon: Settings,
    title: "Strak systeem",
    description: "Campagnes, funnels, automatisering en AI werken samen als één geheel.",
  },
];

const ResultsSection = () => {
  const { ref, revealed } = useScrollReveal();

  return (
    <section
      id="resultaten"
      ref={ref}
      className={`section-padding section-light-blue scroll-reveal ${revealed ? "scroll-reveal-visible" : ""}`}
    >
      <div className="container-narrow">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Wat onze Job Marketing Machine voor jouw bureau betekent
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {results.map((result, index) => (
            <div
              key={index}
              className="bg-background rounded-xl p-7 border border-border card-hover-premium"
            >
              <div className="w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center mb-5">
                <result.icon className="w-7 h-7 text-primary" strokeWidth={1.5} />
              </div>
              <h3 className="text-xl font-semibold mb-3">{result.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{result.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ResultsSection;
