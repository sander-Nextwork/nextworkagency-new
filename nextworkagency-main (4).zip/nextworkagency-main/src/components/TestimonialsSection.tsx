import { Star, ExternalLink, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Carousel, CarouselContent, CarouselItem, type CarouselApi } from "@/components/ui/carousel";
import { useCarouselAutoplay } from "@/hooks/use-carousel-autoplay";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { useEffect, useState } from "react";

interface VideoTestimonial {
  embedId: string;
  title: string;
  isShort?: boolean;
}

// Real video testimonials with YouTube embeds
const videoTestimonials = [
  {
    embedId: "5wXHi6XGYhE",
    title: "Recruiters Network – 4 plaatsingen in één maand",
  },
  {
    embedId: "BeBjuC_F3ko",
    title: "Solvers – 8 plaatsingen in 7 maanden",
  },
  {
    embedId: "Spt6pwH_THs",
    title: "Nimax – 7 plaatsingen voor meerdere functies",
  },
  {
    embedId: "ap6YwEDXDJc",
    title: "Flexconnect – 4 plaatsingen in één maand",
  },
  {
    embedId: "ZYiTQD5mmxw",
    title: "VertX – 3 plaatsingen in 1 maand",
  },
  {
    embedId: "8a9wIk8jNdY",
    title: "Bouwcenter RAB – meer dan 15 vacatures vervuld",
    isShort: true,
  },
];

const googleReviews = [
  {
    name: "Bob van den Tweel",
    text: "Binnen 7 dagen(!) hadden we al de juiste kandidaat. Doe het niet zelf en schakel deze professionals in!",
  },
  {
    name: "Ruben Smink",
    text: "Nextwork heeft mij geholpen aan meerdere goede krachten. Consistente instroom, hoge kwaliteit — zeker een aanrader.",
  },
  {
    name: "Samuel de Kievit",
    text: "In 2 weken al topresultaten binnen de transportsector. Snelle communicatie en eerlijk advies.",
  },
  {
    name: "Sander Dirks",
    text: "Erg tevreden over het aantal Data Consultant sollicitanten dat we hebben ontvangen. Transparant en effectief.",
  },
  {
    name: "Joey Reker",
    text: "Schakelen snel, denken mee en leveren resultaat. Fijne samenwerking!",
  },
  {
    name: "Dennis Schouwstra (RAB)",
    text: "Binnen enkele dagen meerdere goede sollicitaties. Zeker voor herhaling vatbaar.",
  },
  {
    name: "Dani Hertsenberg (SEWA)",
    text: "Binnen een week meer dan 10 aanmeldingen → 3 gesprekken → 2 hires. Een aanrader!",
  },
  {
    name: "Toine",
    text: "Professioneel en persoonlijk. Binnen korte tijd meerdere passende kandidaten. Zeer tevreden.",
  },
  {
    name: "Désanne Valkenberg",
    text: "Binnen zeer korte tijd geholpen aan veel nieuwe medewerkers. Aanrader en waar voor je geld.",
  },
];

const AUTO_ADVANCE_MS = 8000;

const TestimonialsSection = () => {
  const [currentVideo, setCurrentVideo] = useState(0);
  const [videoApi, setVideoApi] = useState<CarouselApi | null>(null);
  const [reviewsApi, setReviewsApi] = useState<CarouselApi | null>(null);
  const { pause: pauseVideos, resume: resumeVideos } = useCarouselAutoplay(videoApi, { delay: AUTO_ADVANCE_MS });
  const { pause: pauseReviews, resume: resumeReviews } = useCarouselAutoplay(reviewsApi, { delay: 2600 });
  const { ref, revealed } = useScrollReveal();
  const totalVideos = videoTestimonials.length;
  const activeVideoIndices = new Set([
    currentVideo,
    (currentVideo + 1) % totalVideos,
    (currentVideo - 1 + totalVideos) % totalVideos,
  ]);

  useEffect(() => {
    if (!videoApi) {
      return;
    }

    const updateIndex = () => {
      setCurrentVideo(videoApi.selectedScrollSnap());
    };

    updateIndex();
    videoApi.on("select", updateIndex);
    videoApi.on("reInit", updateIndex);

    return () => {
      videoApi.off("select", updateIndex);
      videoApi.off("reInit", updateIndex);
    };
  }, [videoApi]);

  return (
    <section
      id="reviews"
      ref={ref}
      className={`section-padding section-light-blue scroll-reveal ${revealed ? "scroll-reveal-visible" : ""}`}
    >
      <div className="container-narrow">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Wat klanten over ons zeggen
          </h2>
        </div>

        {/* Video Testimonials Slider */}
        <div className="mb-20">
          <h3 className="text-lg font-semibold text-center mb-8 text-muted-foreground">
            Video testimonials
          </h3>
          
          <Carousel
            opts={{ loop: true, duration: 28 }}
            setApi={setVideoApi}
            className="relative max-w-3xl mx-auto"
            onMouseEnter={pauseVideos}
            onMouseLeave={resumeVideos}
            onFocusCapture={pauseVideos}
            onBlurCapture={resumeVideos}
            onTouchStart={pauseVideos}
            onTouchEnd={resumeVideos}
            onTouchCancel={resumeVideos}
            aria-label="Video testimonials carousel"
          >
            <CarouselContent className="ml-0">
              {videoTestimonials.map((video, index) => {
                const shouldLoad = activeVideoIndices.has(index);
                return (
                  <CarouselItem key={video.embedId} className="pl-0">
                    <div className="rounded-xl overflow-hidden shadow-xl border border-border bg-background">
                      <div className={video.isShort ? "aspect-[9/16] max-h-[500px] mx-auto" : "aspect-video"}>
                        {shouldLoad ? (
                          <iframe
                            src={`https://www.youtube.com/embed/${video.embedId}?rel=0`}
                            title={video.title}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            loading="lazy"
                            className="w-full h-full"
                          />
                        ) : (
                          <div
                            className="w-full h-full bg-muted flex items-center justify-center text-sm text-muted-foreground"
                            aria-hidden="true"
                          >
                            Video wordt geladen
                          </div>
                        )}
                      </div>
                      <div className="p-4 text-center">
                        <p className="font-medium text-foreground">{video.title}</p>
                      </div>
                    </div>
                  </CarouselItem>
                );
              })}
            </CarouselContent>

            {/* Navigation buttons */}
            <button
              onClick={() => videoApi?.scrollPrev()}
              className="absolute left-2 sm:left-0 top-1/2 -translate-y-1/2 sm:-translate-x-4 lg:-translate-x-12 w-10 h-10 rounded-full bg-background shadow-lg border border-border flex items-center justify-center hover:bg-secondary transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              aria-label="Vorige video"
            >
              <ChevronLeft className="w-5 h-5 text-foreground" />
            </button>
            <button
              onClick={() => videoApi?.scrollNext()}
              className="absolute right-2 sm:right-0 top-1/2 -translate-y-1/2 sm:translate-x-4 lg:translate-x-12 w-10 h-10 rounded-full bg-background shadow-lg border border-border flex items-center justify-center hover:bg-secondary transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              aria-label="Volgende video"
            >
              <ChevronRight className="w-5 h-5 text-foreground" />
            </button>

            {/* Dots indicator */}
            <div className="flex justify-center gap-2 mt-6">
              {videoTestimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => videoApi?.scrollTo(index)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    index === currentVideo ? "bg-primary w-7" : "bg-primary/30"
                  }`}
                  aria-label={`Ga naar video ${index + 1}`}
                />
              ))}
            </div>
          </Carousel>
        </div>

        {/* Google Reviews carousel */}
        <div className="bg-background rounded-2xl py-12 px-4">
          <h3 className="text-lg font-semibold text-center mb-8 text-muted-foreground">
            Google Reviews
          </h3>
          
          <Carousel
            opts={{ align: "start", loop: true, duration: 24 }}
            setApi={setReviewsApi}
            className="relative"
            onMouseEnter={pauseReviews}
            onMouseLeave={resumeReviews}
            onFocusCapture={pauseReviews}
            onBlurCapture={resumeReviews}
            onTouchStart={pauseReviews}
            onTouchEnd={resumeReviews}
            onTouchCancel={resumeReviews}
            aria-label="Google reviews carousel"
          >
            {/* Gradient overlays */}
            <div className="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />

            <CarouselContent>
              {googleReviews.map((review, index) => (
                <CarouselItem key={index} className="basis-4/5 sm:basis-1/2 lg:basis-1/3">
                  <div className="bg-background rounded-xl p-5 shadow-sm border border-border h-full">
                    <div className="flex items-center gap-0.5 mb-3">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-star text-star" />
                      ))}
                    </div>
                    <p className="font-semibold mb-2 text-sm">{review.name}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">"{review.text}"</p>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>

          <div className="text-center mt-10">
            <Button variant="outline" size="lg" asChild>
              <a href="https://share.google/OillkzrgTPPloEF01" target="_blank" rel="noopener noreferrer">
                Bekijk alle reviews op Google
                <ExternalLink className="w-4 h-4 ml-2" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
