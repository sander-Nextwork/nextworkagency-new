import { Linkedin, Mail, Phone } from "lucide-react";
import teamSander from "@/assets/team/team-sander.jpg";
import teamMax from "@/assets/team/team-max.jpg";
import teamRances from "@/assets/team/team-rances.jpg";
import teamBenjamin from "@/assets/team/team-benjamin.png";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";

const team = [
  {
    name: "Sander Valkenberg",
    role: "Mede-eigenaar & Sales",
    image: teamSander,
    email: "sander@nextworkagency.nl",
    phone: "06 23900123",
    linkedin: "https://www.linkedin.com/in/sander-valkenberg-job-marketing/",
  },
  {
    name: "Max Heere",
    role: "Founder & Marketing Manager",
    image: teamMax,
    email: "max@nextworkagency.nl",
    phone: "06 29540868",
    linkedin: "https://www.linkedin.com/in/max-heere-b689951a1/",
  },
  {
    name: "Rances Vos",
    role: "Sales Consultant",
    image: teamRances,
    email: "rances@nextworkagency.nl",
    phone: "06 25351249",
    linkedin: "https://www.linkedin.com/in/rances-vos-5454201aa/",
  },
  {
    name: "Benjamin Geersing",
    role: "Marketeer",
    image: teamBenjamin,
    email: "benjamin@nextworkagency.nl",
    phone: "06 49689659",
    linkedin: "https://www.linkedin.com/in/benjamin-geersing-b6a19a198/",
  },
];

const TeamSection = () => {
  const { ref, revealed } = useScrollReveal();

  return (
    <section
      id="team"
      ref={ref}
      className={`section-padding section-light-blue pb-20 scroll-reveal ${revealed ? "scroll-reveal-visible" : ""}`}
    >
      <div className="container">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ons team
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 items-stretch">
          {team.map((member, index) => (
            <div 
              key={index} 
              className="bg-background rounded-xl p-6 border border-border text-center team-card-hover flex flex-col min-h-[360px]"
            >
              {/* Photo - perfect circle with equal diameter */}
              <div className="w-28 h-28 rounded-full mx-auto mb-5 overflow-hidden bg-muted border-2 border-primary/10 flex-shrink-0">
                <img
                  src={member.image}
                  alt={member.name}
                  loading="lazy"
                  decoding="async"
                  width={112}
                  height={112}
                  className="w-full h-full object-cover object-top"
                />
              </div>

              <div className="flex-shrink-0">
                <h3 className="text-lg font-semibold mb-1 leading-tight">{member.name}</h3>
                <p className="text-sm text-muted-foreground mb-4 leading-tight">{member.role}</p>
              </div>

              <div className="space-y-2.5 mt-auto pt-2">
                <a
                  href={member.linkedin}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors h-5"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Linkedin className="w-4 h-4 flex-shrink-0" />
                  <span>LinkedIn</span>
                </a>
                <a
                  href={`mailto:${member.email}`}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors h-5"
                >
                  <Mail className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{member.email}</span>
                </a>
                <a
                  href={`tel:${member.phone.replace(/\s/g, "")}`}
                  className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors h-5"
                >
                  <Phone className="w-4 h-4 flex-shrink-0" />
                  <span>{member.phone}</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TeamSection;
