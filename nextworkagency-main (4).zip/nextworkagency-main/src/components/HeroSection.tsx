import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";
import { scrollToId } from "@/lib/utils";

const HeroSection = () => {
  const scrollToCalendly = () => {
    scrollToId("calendly");
  };

  return (
    <section className="hero-gradient pt-32 pb-20 md:pt-40 md:pb-28 lg:pt-48 lg:pb-36">
      <div className="container-narrow text-center">
        <h1 className="text-3xl md:text-4xl lg:text-5xl xl:text-[3.25rem] font-bold leading-tight mb-8 animate-fade-in-up max-w-[880px] mx-auto">
          Meer plaatsingen voor jouw bureau dankzij een voorspelbare stroom gekwalificeerde kandidaten.
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-[800px] mx-auto mb-12 leading-relaxed md:leading-loose animate-fade-in-up animation-delay-100">
          Door diepgaand inzicht in jouw doelgroep, krachtige marketingfunnels en een slimme Job Marketing Machine realiseren wij een constante stroom van gekwalificeerde kandidaten voor jouw bureau. Automatisering, diepgaande analyses en dagelijkse optimalisatie houden alles draaiende, zodat jouw team zich volledig kan richten op plaatsingen en groei.
        </p>

        {/* Trust Element */}
        <div className="flex flex-col items-center gap-3 mb-12 animate-fade-in-up animation-delay-200">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-star text-star" />
            ))}
            <span className="ml-2 font-semibold text-foreground">5/5 op Google</span>
            <span className="text-muted-foreground">(22 reviews)</span>
          </div>
          <p className="text-sm text-muted-foreground italic">
            Geloof ons niet, geloof onze klanten.
          </p>
          <p className="text-xs text-muted-foreground/80 mt-1">
            Al meer dan 100 bedrijven geholpen.
          </p>
        </div>

        {/* CTA Button */}
        <div className="animate-fade-in-up animation-delay-300">
          <Button variant="hero" size="xl" onClick={scrollToCalendly}>
            Plan een demo met Sander
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
