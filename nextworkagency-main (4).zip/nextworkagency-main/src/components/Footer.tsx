import logoNextwork from "@/assets/logo-nextwork.png";

const Footer = () => {
  return (
    <footer className="py-12 border-t border-border">
      <div className="container-wide">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <img
              src={logoNextwork}
              alt="Nextwork Agency"
              loading="lazy"
              decoding="async"
              className="w-40 object-contain mix-blend-multiply"
            />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <a
              href="mailto:info@nextworkagency.nl"
              className="hover:text-foreground transition-colors"
            >
              info@nextworkagency.nl
            </a>
            <span className="hidden md:inline">|</span>
            <a
              href="tel:0623900123"
              className="hover:text-foreground transition-colors"
            >
              06 23 90 01 23
            </a>
          </div>

          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Nextwork Agency
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
