import { useEffect, useRef } from "react";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";

const CalendlySection = () => {
  const { ref, revealed } = useScrollReveal({ threshold: 0.1, rootMargin: "0px 0px -20% 0px" });
  const hasLoadedScript = useRef(false);

  useEffect(() => {
    if (!revealed || hasLoadedScript.current) {
      return;
    }

    const existingScript = document.querySelector('script[src="https://assets.calendly.com/assets/external/widget.js"]');
    if (existingScript) {
      hasLoadedScript.current = true;
      return;
    }

    // Load Calendly widget script only when the section is in view
    const script = document.createElement("script");
    script.src = "https://assets.calendly.com/assets/external/widget.js";
    script.async = true;
    document.body.appendChild(script);
    hasLoadedScript.current = true;
  }, [revealed]);

  return (
    <section
      id="calendly"
      ref={ref}
      className={`section-padding section-grey-blue scroll-reveal ${revealed ? "scroll-reveal-visible" : ""}`}
    >
      <div className="container-narrow">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Plan een vrijblijvende demo met Sander
          </h2>
          <p className="text-lg text-muted-foreground">
            Ontdek in 30 minuten hoe de Job Marketing Machine kan werken voor jouw bureau.
          </p>
        </div>

        <div className="bg-background rounded-xl p-4 shadow-sm border border-border">
          <div
            className="calendly-inline-widget h-[70vh] min-h-[520px] sm:h-[700px]"
            data-url="https://calendly.com/sandernextworkagency/30min?hide_event_type_details=1&hide_gdpr_banner=1"
            style={{ minWidth: "320px" }}
          />
        </div>
      </div>
    </section>
  );
};

export default CalendlySection;
