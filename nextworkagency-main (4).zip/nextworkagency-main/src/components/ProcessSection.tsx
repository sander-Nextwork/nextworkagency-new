import { Search, Wrench, LineChart, Target } from "lucide-react";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";

const steps = [
  {
    icon: Search,
    step: "01",
    title: "Analyse van jouw doelgroep",
    description: "Diep onderzoek naar gedrag, motivaties en wervingsdrijfveren.",
  },
  {
    icon: Wrench,
    step: "02",
    title: "Creatie van het volledige marketingsysteem",
    description: "Ads, funnels, automatiseringen en messaging worden op maat gebouwd.",
  },
  {
    icon: LineChart,
    step: "03",
    title: "Dagelijkse optimalisatie door een senior team",
    description: "We zitten er bovenop, lezen data uit en sturen continu bij.",
  },
  {
    icon: Target,
    step: "04",
    title: "Jij focust op plaatsen",
    description: "Wij zorgen voor de instroom, jij voor de groei van je bureau.",
  },
];

const ProcessSection = () => {
  const { ref, revealed } = useScrollReveal();

  return (
    <section
      id="werkwijze"
      ref={ref}
      className={`section-padding section-white scroll-reveal ${revealed ? "scroll-reveal-visible" : ""}`}
    >
      <div className="container-narrow">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Hoe wij resultaat behalen voor jouw bureau
          </h2>
        </div>

        <div className="relative">
          {/* Horizontal connecting line for desktop - centered through icons */}
          <div className="hidden lg:block absolute top-10 left-0 h-[2px] bg-primary/15 w-[80%]" />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-6">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="text-center lg:text-left">
                  <div className="relative z-10 inline-flex items-center justify-center w-20 h-20 rounded-full bg-background border-2 border-primary/20 mb-6">
                    <step.icon className="w-8 h-8 text-primary" strokeWidth={1.5} />
                  </div>
                  
                  <div className="text-xs font-bold text-primary/60 uppercase tracking-wider mb-2">
                    Stap {step.step}
                  </div>
                  
                  <h3 className="text-lg font-semibold mb-3">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
